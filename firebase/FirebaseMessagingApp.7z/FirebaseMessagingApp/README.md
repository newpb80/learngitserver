# Howl
<p align="center">
Firebase Instant Messaging and Push Notification App with Firebase Database and Storage technology.
  This is an old project and same time my finishing thesis for university.
</p>

<p align="center"><a href='https://ko-fi.com/B0B2TZMH' target='_blank'><img height='36' style='border:0px;height:36px;' src='https://az743702.vo.msecnd.net/cdn/kofi1.png?v=2' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a></p>

<p align="center">
Register with mail
</p>

<p align="center">
<img src="https://s19.postimg.cc/vp1sl5k77/image.png" width="250px" />
</p>

<p align="center">
Then you can see all people who are using Howl, add them as a friend and they can add too.
</p>

<p align="center">
<img src="https://s19.postimg.cc/xgurg4gfn/image.png" width="250px" /> <img src="https://s19.postimg.cc/eoiwcip6b/image.png" width="250px" /> <img src="https://s19.postimg.cc/5gqnvt2oj/image.png" width="250px" />
</p>

<p align="center">
List your friend and chat with them
</p>

<p align="center">
<img src="https://s19.postimg.cc/ikw88hn0j/image.png" width="250px" /> <img src="https://s19.postimg.cc/bhocswk5v/image.png" width="250px" />
</p>

<p align="center">
You can change your profile informations and when you do not want to get notification you can log out.
</p>

<p align="center">
<img src="https://s19.postimg.cc/fqt2v2v4z/image.png" width="250px" /> <img src="https://s19.postimg.cc/tkhfk48ar/image.png" width="250px" />
</p>
